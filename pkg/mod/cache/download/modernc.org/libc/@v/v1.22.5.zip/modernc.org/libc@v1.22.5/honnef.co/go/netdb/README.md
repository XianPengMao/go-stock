# netdb

## Install

```sh
go get honnef.co/go/netdb
```

## Documentation

Documentation can be found at
[godoc.org](http://godoc.org/honnef.co/go/netdb).
