# tcl

Package tcl is a CGo-free port of the Tool Command Language (Tcl).

Tcl is a very powerful but easy to learn dynamic programming language, suitable
for a very wide range of uses, including web and desktop applications,
networking, administration, testing and many more.
