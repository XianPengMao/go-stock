package flags

type Common struct {
	NoColour bool `description:"Disable colour in output"`
}
