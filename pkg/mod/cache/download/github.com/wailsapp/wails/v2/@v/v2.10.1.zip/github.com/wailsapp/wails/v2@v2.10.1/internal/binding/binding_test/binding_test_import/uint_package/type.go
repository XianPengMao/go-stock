package uint_package

type SomeStruct struct {
	Name string `json:"string"`
}
