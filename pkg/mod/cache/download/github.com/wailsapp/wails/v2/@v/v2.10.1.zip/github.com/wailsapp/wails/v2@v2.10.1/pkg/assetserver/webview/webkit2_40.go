//go:build linux && webkit2_40

package webview

const Webkit2MinMinorVersion = 40
