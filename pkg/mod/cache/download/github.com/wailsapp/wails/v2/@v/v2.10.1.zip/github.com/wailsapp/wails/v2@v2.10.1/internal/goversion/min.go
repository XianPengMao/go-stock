package goversion

const MinRequirement string = "1.20"
