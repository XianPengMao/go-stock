package menu

/*
// DefaultMacMenu returns a default menu including the default
// Application and Edit menus. Use `.Append()` to add to it.
func DefaultMacMenu() *Menu {
	return NewMenuFromItems(
		AppMenu(),
		EditMenu(),
	)
}
*/
