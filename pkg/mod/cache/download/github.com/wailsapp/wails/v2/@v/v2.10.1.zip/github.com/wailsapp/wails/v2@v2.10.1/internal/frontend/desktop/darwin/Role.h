//
//  Role.h
//  test
//
//  Created by Lea Anthony on 24/10/21.
//

#ifndef Role_h
#define Role_h

typedef int Role;

static const Role AppMenu = 1;
static const Role EditMenu = 2;
static const Role WindowMenu = 3;

#endif /* Role_h */
