//go:build !windows
// +build !windows

package application

func applicationInit() error {
	return nil
}
