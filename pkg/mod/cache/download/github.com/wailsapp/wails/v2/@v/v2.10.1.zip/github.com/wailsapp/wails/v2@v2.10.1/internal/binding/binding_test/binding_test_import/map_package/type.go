package map_package

type SomeStruct struct {
	Name string `json:"string"`
}
