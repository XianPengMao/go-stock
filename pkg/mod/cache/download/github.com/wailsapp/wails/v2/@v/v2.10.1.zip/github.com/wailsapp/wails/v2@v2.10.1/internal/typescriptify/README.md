Based on: https://github.com/tkrajina/typescriptify-golang-structs
License: LICENSE.txt