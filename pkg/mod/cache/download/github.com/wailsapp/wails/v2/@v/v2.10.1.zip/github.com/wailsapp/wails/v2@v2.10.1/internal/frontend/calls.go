package frontend

type Calls interface {
	Callback(message string)
}
