# Menus

Menu support is heavily inspired by Electron's approach.

## Features

  * Supports Text, Checkbox, Radio, Submenu and Separator
  * Radio groups are defined as any number of adjacent radio items
  * UTF-8 menu labels
  * UTF-8 menu IDs