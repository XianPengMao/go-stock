package cfd

import "errors"

var (
	ErrCancelled = errors.New("cancelled by user")
)
