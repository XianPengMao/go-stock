//go:build windows

package webview2

type COREWEBVIEW2_PHYSICAL_KEY_STATUS struct {
	RepeatCount   uint32
	ScanCode      uint32
	IsExtendedKey bool
	IsMenuKeyDown bool
	WasKeyDown    bool
	IsKeyReleased bool
}
