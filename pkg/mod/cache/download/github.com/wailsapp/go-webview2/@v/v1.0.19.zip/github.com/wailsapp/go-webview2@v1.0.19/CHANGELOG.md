# CHANGELOG

## [Unreleased]

- Added support for drag and drop of files and folders. [@ayatkyo](https://github.com/ayatkyo) in [#1](https://github.com/wailsapp/go-webview2/pull/1).