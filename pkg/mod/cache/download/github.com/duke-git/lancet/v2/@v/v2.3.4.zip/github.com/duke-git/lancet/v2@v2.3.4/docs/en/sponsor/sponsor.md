

### Sponsor me

<b>Hello, I am a software developer and have been engaged in development work for 15 years. Love open source software. And be willing to put in the energy for it. I am the creator of project [lancet](https://github.com/duke-git/lancet). Since Lancet was released as open source in 2021, it has been used by more than 1700 internal and external projects. lancet will always be free for all users. Your support is a powerful encouragement for me to continue my struggle. Thanks! You can use WeChat to scans the following QR code or clicks the following sponsor button to initiate sponsorship.</b>

<style>
    .sponsor-ctn {
        position: relative;
        display: inline-block;
    }
    .sponsor-pay {
        display: inline-block;
        float: right;
    }
    .sponsor-btn {
        border-color: #4565d8;
        color: #fff;
        background-color: #4565d8;
        border-radius: 20px;
        padding: 0 20px;
        line-height: 40px;
        font-size: 16px;
        display: inline-block;
        border: 1px solid transparent;
        text-align: center;
        width: 140px;
        position: absolute;
        left: 360px;
        top: 120px;
    }
</style>

<div class="sponsor-ctn"> 
<img src="/public/wechat_pay.png" width="260" height="260" class="sponsor-pay"/>

<a class="sponsor-btn" style="color: #fff;font-weight: 600;" href="https://en.liberapay.com/Duke_Du/donate" target="\_blank">Sponsor</a>

</div>

*Donated funds will be used to maintain this website and pay for cloud server costs. Or just buy me a cup of ☕️ when I'm sleepy writing code.*