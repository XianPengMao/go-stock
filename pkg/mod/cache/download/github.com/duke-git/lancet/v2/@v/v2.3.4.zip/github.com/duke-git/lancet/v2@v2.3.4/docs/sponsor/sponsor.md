### 赞助

<b>您好，我是一名软件开发者，从事开发工作15年。热爱软件开源。并愿意为此付出精力。是开源项目[lancet](https://github.com/duke-git/lancet)的作者。Lancet自2021年前开源发布以来，已有超过1700个内外部项目使用。lancet一直会对所有用户免费。您的支持是对我继续奋斗的有力鼓励。谢谢! 微信扫描以下二维码或点击以下赞助按钮发起赞助。 </b>

<style>
    .sponsor-ctn {
        position: relative;
        display: inline-block;
    }
    .sponsor-pay {
        display: inline-block;
        float: right;
    }
    .sponsor-btn {
        border-color: #4565d8;
        color: #fff;
        background-color: #4565d8;
        border-radius: 20px;
        padding: 0 20px;
        line-height: 40px;
        font-size: 16px;
        display: inline-block;
        border: 1px solid transparent;
        text-align: center;
        width: 140px;
        position: absolute;
        left: 360px;
        top: 120px;
    }
</style>
<div class="sponsor-ctn"> 
<img src="../public/wechat_pay.png" width="260" height="260" class="sponsor-pay"/>

<a class="sponsor-btn" style="color: #fff;font-weight: 600;" href="https://liberapay.com/Duke_Du/donate" target="\_blank">赞助</a>

</div>

*捐赠的资金将用于 lancet官网的维护和云服务器的费用支付。或者当我写代码困倦时，给我买杯 ☕️。*
