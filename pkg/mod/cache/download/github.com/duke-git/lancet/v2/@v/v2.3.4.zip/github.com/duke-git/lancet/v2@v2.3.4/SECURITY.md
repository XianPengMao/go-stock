# Security Policy

## Supported Versions
Here is the lancet version and compatibility with go language version.

| Version | Supported         |
| ------- | ------------------|
| 2.x.x   | +go v1.18         |
| 1.x.x   | +go v1.12         |


## Reporting a Vulnerability

For now, there is no public website to report a vulnerability, If you find security issue in lancet, you can send it to me via my email `lanliddd.2007@163.com`.
we can discuss it. I am appreciate if someone can create a public page for reporting vulnerability.
