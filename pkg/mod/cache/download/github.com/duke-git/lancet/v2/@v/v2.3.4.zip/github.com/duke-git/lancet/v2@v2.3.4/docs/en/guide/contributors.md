# Contributors
<b>Thank you to all the people who contributed to lancet!</b>

<a href="https://github.com/duke-git/lancet/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=duke-git/lancet" />
</a>