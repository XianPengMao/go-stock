<a name="unreleased"></a>
## [Unreleased]


<a name="v1.3.1"></a>
## [v1.3.1] - 2019-03-03
### Fix
- Fix Float tests


<a name="v1.3.0"></a>
## [v1.3.0] - 2019-03-03
### Feat
- Add optional slice as part of construction


<a name="v1.2.0"></a>
## [v1.2.0] - 2019-02-26
### Chore
- add changelog

### Feat
- Add Slicer.Each()


<a name="v1.1.0"></a>
## [v1.1.0] - 2019-02-26
### Feat
- Added Filter


<a name="v1.0.0"></a>
## v1.0.0 - 2019-01-13

[Unreleased]: https://github.com/leaanthony/slicer/compare/v1.3.1...HEAD
[v1.3.1]: https://github.com/leaanthony/slicer/compare/v1.3.0...v1.3.1
[v1.3.0]: https://github.com/leaanthony/slicer/compare/v1.2.0...v1.3.0
[v1.2.0]: https://github.com/leaanthony/slicer/compare/v1.1.0...v1.2.0
[v1.1.0]: https://github.com/leaanthony/slicer/compare/v1.0.0...v1.1.0
