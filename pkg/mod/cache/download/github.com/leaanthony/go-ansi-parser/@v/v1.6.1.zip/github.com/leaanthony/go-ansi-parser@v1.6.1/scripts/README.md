This script is used to regenerate the colour definitions used by go-ansi-parser.

This script makes use of the colours defined [here](https://jonasjacek.github.io/colors/) which are licensed using the [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/). 