void configureAppWindow(char* title, int width, int height);
void showAppWindow(char* url);

