function attribute(n) {
    return this[n];
}
